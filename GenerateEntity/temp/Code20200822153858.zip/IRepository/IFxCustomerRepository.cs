﻿
//--------------------------------------------------------------------
//     此代码由T4模板自动生成
//	   生成时间 2020/8/22 15:39:47
//     对此文件的更改可能会导致不正确的行为，并且如果重新生成代码，这些更改将会丢失。
//--------------------------------------------------------------------

using System;
using Entity;
namespace IRepository
{
	/// <summary>
	/// 客户表(fx_customer)
	/// </summary>
	public interface IFxCustomerRepository : IBaseRepository<FxCustomer>
	{
	}
}